﻿console.log("myApp");

function loadtest(){

    let requestURL = "data/charac.json";
    let request = new XMLHttpRequest();
    request.open('GET', requestURL);
    request.responseType = 'json';
    request.send();
    request.onload = function() {
      const diaryForm = request.response;
      add("index_container",diaryForm);
    }
}
loadtest();

function add(obj,jsonObj){
    var diaries = jsonObj['diaries'];
    for(i = 0; i < diaries.length; i++) {
        addElement(obj,diaries[i]);
    }
}



function addElement(obj,index) {
	var parent = document.getElementById(obj);
	var a = document.createElement("a");
	//a.setAttribute("href", "page"+i+".html");
	a.setAttribute("href", "mail.html?year=2021");
	a.setAttribute("class", "ic_a");
	var div = document.createElement("div");
	div.setAttribute("class", "index_container-mail_"+i%2);
	var title = index.title;
	div.innerHTML = title;
	a.appendChild(div);
	parent.appendChild(a);
	console.log("112ss3");
}


/*
function addss() {
	for (i = 0; i < 36; i++) { 
		addElementDiv("index_container",i);
	}
}
addss();*/